<?php
// session_start();
// include 'header.php';
// if (!isset($_SESSION['Gebruikersnaam'])){
//     header("location:inlog.php");
// } else{
//     echo "<p>Welkom, " . $_SESSION['Gebruikersnaam'] . "</p>";

//     if ($_SESSION['level'] == 0){
//         echo "<p> U heeft geen rechten om deze pagina te bekijken.</p>";
//         echo "<p><a href='band_uilees.php'>terug</a></p>";
//     }
// }

if (isset($_POST['submit'])){
    require '../config.php';

    $userid = $_POST['ID_vraag'];
    

    $query = "DELETE FROM fabelsenfeiten WHERE ID_vraag= " . $userid;

    

    if (mysqli_query($mysqli, $query)){
        echo "<p> deze vraag is verwijderd!</p>";
    }
    else{
        echo "<p> FOUT bij verwijderen van vraag.</p>";
        echo mysqli_error($mysqli);
    }
} else {
    echo "<p> Geen gegevens gevonden...</p>";
}
echo "<p><a href='Activiteiten.php'>TERUG<a/> <p/>";
?>
